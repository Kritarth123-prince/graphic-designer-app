const { getOrCreateSettings, updateSettings } = require('../services/settings.service');
const { savePreviewImage, previewFilePath } = require('../services/fileStorage.service');
const { isValidImage } = require('../utils/fileSignature');

// Whitelist what a PUT can touch, so a stray field in the body can't
// clobber _id/timestamps or add junk keys outside the schema. Also
// reused below as the public GET projection — same list, two jobs.
const ALLOWED_FIELDS = [
  'designerName',
  'logoUrl',
  'faviconUrl',
  'heroTitle',
  'heroSubtitle',
  'heroImageUrl',
  'aboutText',
  'profileImageUrl',
  'whatsappNumber',
  'email',
  'upi',
  'social',
  'footerText',
];

// A whitelist, not an exclusion list — deliberately. An exclusion list
// (keep everything except X) quietly leaks any new field added later
// unless someone remembers to add it to the exclusion list too. This
// only ever returns fields someone consciously decided belong here —
// Mongo internals like _id/createdAt/updatedAt/__v were never on this
// list and never needed to be, since nothing on the public site reads
// them.
function toPublicSettings(settings) {
  const obj = settings.toObject ? settings.toObject() : { ...settings };
  const publicView = {};
  for (const field of ALLOWED_FIELDS) {
    if (obj[field] !== undefined) publicView[field] = obj[field];
  }
  return publicView;
}

async function getSettings(req, res) {
  const settings = await getOrCreateSettings();
  return res.json({ success: true, settings: toPublicSettings(settings) });
}

// Admin-only — the full document, including `upi`, for the settings
// form itself to read and edit.
async function getSettingsAdmin(req, res) {
  const settings = await getOrCreateSettings();
  return res.json({ success: true, settings });
}

async function putSettings(req, res) {
  const patch = {};
  for (const key of ALLOWED_FIELDS) {
    if (Object.prototype.hasOwnProperty.call(req.body, key)) {
      patch[key] = req.body[key];
    }
  }

  const settings = await updateSettings(patch);
  return res.json({ success: true, settings });
}

// Generic image upload for any settings image field (logo, favicon, hero
// image, profile image, UPI QR) — one endpoint, the frontend decides
// which field to drop the returned URL into. Same public Cloudinary
// storage and magic-byte verification as product/portfolio previews.
async function uploadSettingsImage(req, res) {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No file uploaded.' });
  }
  if (!isValidImage(req.file.buffer)) {
    return res.status(400).json({
      success: false,
      message: 'File content does not match a valid JPEG, PNG, or WebP image.',
    });
  }

  const key = await savePreviewImage(req.file.buffer, req.file.originalname);
  return res.status(201).json({ success: true, url: previewFilePath(key) });
}

module.exports = { getSettings, getSettingsAdmin, putSettings, uploadSettingsImage };

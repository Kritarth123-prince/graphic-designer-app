const bcrypt = require('bcryptjs');
const { AdminUser } = require('../models');
const { signAdminToken } = require('../utils/token');
const { SESSION_COOKIE_NAME, sessionCookieOptions } = require('../config/cookie');

// Generic message on purpose — never reveal whether the email exists.
const INVALID_CREDENTIALS_MESSAGE = 'Invalid email or password.';

async function login(req, res) {
  const { email, password } = req.body;

  const admin = await AdminUser.findOne({ email }).select('+passwordHash');
  if (!admin) {
    return res.status(401).json({ success: false, message: INVALID_CREDENTIALS_MESSAGE });
  }

  const passwordMatches = await bcrypt.compare(password, admin.passwordHash);
  if (!passwordMatches) {
    return res.status(401).json({ success: false, message: INVALID_CREDENTIALS_MESSAGE });
  }

  admin.lastLogin = new Date();
  await admin.save();

  const token = signAdminToken(admin);
  res.cookie(SESSION_COOKIE_NAME, token, sessionCookieOptions());

  return res.json({
    success: true,
    // Also returned in the body, not just set as a cookie — Safari/iOS
    // (all browsers there use WebKit) aggressively restricts cross-site
    // cookies via Intelligent Tracking Prevention, which can silently
    // block the cookie from ever being stored or sent when the frontend
    // and API are on different domains, even with SameSite=None; Secure
    // set correctly. The frontend sends this back as an
    // "Authorization: Bearer <token>" header instead, which isn't a
    // cookie and isn't subject to any of that — see
    // middleware/auth.middleware.js, which now accepts either.
    token,
    admin: {
      id: admin._id,
      email: admin.email,
      name: admin.name,
      role: admin.role,
    },
  });
}

async function logout(req, res) {
  res.clearCookie(SESSION_COOKIE_NAME, { ...sessionCookieOptions(), maxAge: 0 });
  return res.json({ success: true, message: 'Logged out.' });
}

async function me(req, res) {
  // req.admin is attached by requireAuth
  const { admin } = req;
  return res.json({
    success: true,
    admin: {
      id: admin._id,
      email: admin.email,
      name: admin.name,
      role: admin.role,
      lastLogin: admin.lastLogin,
    },
  });
}

module.exports = { login, logout, me };

const { verifyAdminToken } = require('../utils/token');
const { SESSION_COOKIE_NAME } = require('../config/cookie');
const { AdminUser } = require('../models');

async function requireAuth(req, res, next) {
  try {
    // Authorization header first — this is what makes admin auth work on
    // Safari/iOS, where the cookie can be silently blocked by ITP for a
    // cross-site frontend/API split. Cookie is the fallback for browsers
    // that handle third-party cookies normally.
    const authHeader = req.headers.authorization || '';
    const headerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    const token = headerToken || req.cookies?.[SESSION_COOKIE_NAME];

    if (!token) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }

    const payload = verifyAdminToken(token);
    const admin = await AdminUser.findById(payload.sub);
    if (!admin) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }

    req.admin = admin;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Session expired or invalid.' });
  }
}

// Reserved for endpoints that only the owner (not a general admin) may hit.
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.admin || !roles.includes(req.admin.role)) {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }
    next();
  };
}

module.exports = { requireAuth, requireRole };

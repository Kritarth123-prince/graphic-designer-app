import axios from 'axios';
import { getToken } from '../utils/tokenStorage';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api',
  withCredentials: true, // still sends the admin session cookie when the browser allows it
});

// Attaches the admin token as an Authorization header on every request,
// when one exists. This is what makes admin auth work on Safari/iOS —
// see server/src/middleware/auth.middleware.js for why the cookie alone
// isn't reliable there. Harmless to attach on every request, including
// public ones with no token set (getToken() returns null, header is
// simply omitted) and including the public site, which never sets a
// token in the first place.
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;

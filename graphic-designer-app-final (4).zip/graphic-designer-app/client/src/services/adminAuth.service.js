import api from './api';
import { setToken, clearToken } from '../utils/tokenStorage';

export async function login(email, password) {
  const { data } = await api.post('/auth/login', { email, password });
  // Stored for the Authorization-header path — see tokenStorage.js and
  // server/src/middleware/auth.middleware.js for why this exists
  // alongside the cookie the backend also sets.
  setToken(data.token);
  return data.admin;
}

export async function logout() {
  try {
    await api.post('/auth/logout');
  } finally {
    // Clear the local token even if the network call fails — an admin
    // clicking "log out" should always end up logged out on this device,
    // regardless of whether the server round-trip succeeded.
    clearToken();
  }
}

export async function me() {
  const { data } = await api.get('/auth/me');
  return data.admin;
}

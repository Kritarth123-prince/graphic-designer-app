import { useState } from 'react';

export default function UpiPaymentDetails({ upi }) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  if (!upi?.id) return null;

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(upi.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API can fail (permissions, non-secure context) — the
      // UPI ID is still shown as plain text either way, so this isn't
      // a dead end for the customer, just a lost convenience.
    }
  }

  return (
    <div className="mt-4 border border-ink/10 p-4 text-sm">
      <p className="text-xs text-ink/40 uppercase tracking-wide">Pay via UPI</p>

      <div className="mt-2 flex items-center justify-between gap-3">
        <span className="font-mono break-all">{upi.id}</span>
        <button onClick={handleCopy} className="text-xs border-b border-gold pb-0.5 shrink-0">
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>

      {upi.qrImageUrl && (
        <>
          <button
            onClick={() => setExpanded(true)}
            className="relative mt-3 block cursor-zoom-in group w-fit"
            aria-label="Expand QR code"
          >
            <img
              src={upi.qrImageUrl}
              alt="UPI QR code — tap to expand"
              className="w-28 h-28 sm:w-32 sm:h-32 object-contain border border-ink/10"
            />
            {/* Zoom-icon badge — a clearer tap affordance than caption text alone */}
            <span className="absolute bottom-1.5 right-1.5 w-6 h-6 rounded-full bg-ink/70 text-ivory flex items-center justify-center group-active:scale-95 transition-transform">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <circle cx="11" cy="11" r="7" />
                <path d="m21 21-4.3-4.3" strokeLinecap="round" />
                <path d="M11 8v6M8 11h6" strokeLinecap="round" />
              </svg>
            </span>
          </button>

          {expanded && (
            <div
              className="fixed inset-0 z-50 bg-ink/95 flex items-center justify-center p-4"
              onClick={() => setExpanded(false)}
            >
              <div
                className="bg-ivory p-5 sm:p-8 w-[85vw] max-w-xs sm:max-w-sm md:max-w-md max-h-[90vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-end">
                  <button
                    onClick={() => setExpanded(false)}
                    aria-label="Close"
                    className="text-ink/40 hover:text-ink text-xl leading-none -mt-1 -mr-1"
                  >
                    ×
                  </button>
                </div>
                <img src={upi.qrImageUrl} alt="UPI QR code" className="w-full h-auto object-contain" />
                <p className="mt-4 text-center font-mono text-sm break-all">{upi.id}</p>
              </div>
            </div>
          )}
        </>
      )}

      {upi.instructions && (
        <p className="mt-3 text-xs text-ink/60 leading-relaxed">{upi.instructions}</p>
      )}
    </div>
  );
}

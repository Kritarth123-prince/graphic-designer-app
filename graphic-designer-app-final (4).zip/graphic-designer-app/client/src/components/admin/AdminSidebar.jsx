import { NavLink } from 'react-router-dom';
import { useAdminAuth } from '../../context/AdminAuthContext';

const NAV = [
  { to: '/admin', label: 'Dashboard', end: true },
  { to: '/admin/products', label: 'Products' },
  { to: '/admin/categories', label: 'Categories' },
  { to: '/admin/portfolio', label: 'Portfolio' },
  { to: '/admin/orders', label: 'Orders' },
  { to: '/admin/inquiries', label: 'Inquiries' },
  { to: '/admin/custom-requests', label: 'Custom Requests' },
  { to: '/admin/settings', label: 'Settings' },
];

export default function AdminSidebar({ open, onClose }) {
  const { admin, logout } = useAdminAuth();

  return (
    <>
      {/* Backdrop — mobile only, closes the drawer when tapped */}
      {open && (
        <div
          className="fixed inset-0 bg-black/40 z-40 md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={`
          fixed md:sticky inset-y-0 md:inset-y-auto md:top-0 left-0 z-50 md:h-screen
          w-64 md:w-56 shrink-0 border-r border-neutral-200 bg-white flex flex-col
          transform transition-transform duration-200 md:transform-none
          ${open ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
        `}
      >
        <div className="h-16 flex items-center justify-between px-5 border-b border-neutral-200">
          <span className="font-semibold text-neutral-900 text-sm">Admin</span>
          <button
            onClick={onClose}
            className="md:hidden text-neutral-400 hover:text-neutral-900 text-xl leading-none"
            aria-label="Close menu"
          >
            ×
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={onClose}
              className={({ isActive }) =>
                `block px-3 py-2 rounded text-sm ${
                  isActive ? 'bg-neutral-900 text-white' : 'text-neutral-600 hover:bg-neutral-100'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-3 py-4 border-t border-neutral-200 text-sm">
          <p className="px-3 text-neutral-500 truncate">{admin?.email}</p>
          <button
            onClick={logout}
            className="mt-2 w-full text-left px-3 py-2 rounded text-neutral-600 hover:bg-neutral-100"
          >
            Log out
          </button>
        </div>
      </aside>
    </>
  );
}

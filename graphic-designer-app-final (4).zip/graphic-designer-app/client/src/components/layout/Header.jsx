import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useSiteSettings } from '../../context/SiteSettingsContext';

const NAV_LINKS = [
  { to: '/shop', label: 'Shop' },
  { to: '/portfolio', label: 'Portfolio' },
  { to: '/about', label: 'About' },
  { to: '/custom-design', label: 'Custom Design' },
  { to: '/contact', label: 'Contact' },
];

export default function Header() {
  const { settings } = useSiteSettings();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="border-b border-ink/10 bg-ivory/95 backdrop-blur sticky top-0 z-40">
      <div className="mx-auto max-w-7xl px-6 md:px-10 h-20 flex items-center justify-between">
        <Link
          to="/"
          onClick={() => setMenuOpen(false)}
          className="flex items-center gap-2.5 font-serif text-xl tracking-tight text-ink"
        >
          {settings.logoUrl ? (
            <img src={settings.logoUrl} alt={settings.designerName || 'Studio'} className="h-8 w-auto object-contain" />
          ) : (
            settings.designerName || 'Studio'
          )}
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `transition-colors hover:text-gold ${isActive ? 'text-ink' : 'text-ink/60'}`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        {/* Mobile: hamburger opens the full nav (same links as desktop) —
            previously showed only Shop/Contact, silently hiding
            Portfolio/About/Custom Design from mobile visitors entirely. */}
        <button
          onClick={() => setMenuOpen((v) => !v)}
          className="md:hidden text-ink"
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
        >
          {menuOpen ? (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
            </svg>
          ) : (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M3 6h18M3 12h18M3 18h18" strokeLinecap="round" />
            </svg>
          )}
        </button>
      </div>

      {menuOpen && (
        <nav className="md:hidden border-t border-ink/10 px-6 py-4 flex flex-col gap-1 bg-ivory">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => setMenuOpen(false)}
              className={({ isActive }) =>
                `py-2.5 text-sm ${isActive ? 'text-ink' : 'text-ink/60'}`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  );
}

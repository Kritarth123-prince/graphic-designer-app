import { useEffect } from 'react';

function setMetaTag(attr, key, content) {
  const el = document.querySelector(`meta[${attr}="${key}"]`);
  if (!content) {
    el?.remove();
    return;
  }
  if (el) {
    el.setAttribute('content', content);
    return;
  }
  const newEl = document.createElement('meta');
  newEl.setAttribute(attr, key);
  newEl.setAttribute('content', content);
  document.head.appendChild(newEl);
}

function setCanonical(url) {
  let el = document.querySelector('link[rel="canonical"]');
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', 'canonical');
    document.head.appendChild(el);
  }
  el.setAttribute('href', url);
}

// JSON-LD structured data (schema.org) — lets search engines show rich
// results (price, availability, ratings) instead of a plain blue link.
// This alone doesn't guarantee ranking — that depends on far more than
// any single page's markup — but it's the concrete, code-level lever
// available here, and a real one search engines do use.
//
// `key` lets more than one structured-data block coexist on the same
// page (e.g. site-wide Organization markup plus a page-specific Product
// block) — each key manages its own <script> tag rather than all
// callers fighting over one shared slot.
function setStructuredData(data, key = 'default') {
  const selector = `script[data-managed="structured-data-${key}"]`;
  let el = document.querySelector(selector);
  if (!data) {
    el?.remove();
    return;
  }
  if (!el) {
    el = document.createElement('script');
    el.setAttribute('type', 'application/ld+json');
    el.setAttribute('data-managed', `structured-data-${key}`);
    document.head.appendChild(el);
  }
  el.textContent = JSON.stringify(data);
}

/**
 * This is a client-rendered SPA with no server-side rendering, so these
 * tags update after the initial HTML loads — fine for browser tabs and
 * for crawlers that execute JS (Google does), but a search engine or
 * social-preview bot that doesn't run JS will only ever see the static
 * defaults in index.html. Worth keeping in mind if that ever matters
 * more than it does for a small storefront like this.
 *
 * `noindex`: set true on placeholder/thin-content pages (e.g. "coming
 * soon") so they don't get indexed and dilute the site's real pages in
 * search results.
 * `type`: og:type — defaults to "website", pass "product" on product pages.
 * `structuredData`: a schema.org object (see productStructuredData below
 * for the shape used on product pages) — cleared automatically when a
 * page doesn't pass one, so it never leaks onto the next page visited.
 */
export function useDocumentMeta({ title, description, image, path, type = 'website', noindex, structuredData }) {
  useEffect(() => {
    if (title) document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('name', 'robots', noindex ? 'noindex, nofollow' : null);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', image);
    setMetaTag('property', 'og:type', type);

    if (path) {
      const origin = window.location.origin;
      setCanonical(`${origin}${path}`);
      setMetaTag('property', 'og:url', `${origin}${path}`);
    }

    setStructuredData(structuredData, 'page');
  }, [title, description, image, path, type, noindex, structuredData]);
}

// Site-wide Organization/ProfessionalService markup — call this once,
// high up in the tree (PublicLayout), independent of whatever
// page-specific structured data useDocumentMeta sets via the 'page' key.
export function useOrganizationStructuredData(settings) {
  useEffect(() => {
    if (!settings?.designerName) return undefined;
    setStructuredData(
      {
        '@context': 'https://schema.org',
        '@type': 'ProfessionalService',
        name: settings.designerName,
        image: settings.logoUrl || settings.profileImageUrl,
        description: settings.aboutText,
        email: settings.email || undefined,
        url: window.location.origin,
        sameAs: Object.values(settings.social || {}).filter((v) => typeof v === 'string' && v),
      },
      'organization'
    );
    return () => setStructuredData(undefined, 'organization');
  }, [settings?.designerName, settings?.logoUrl, settings?.profileImageUrl, settings?.aboutText, settings?.email, settings?.social]);
}

// Builds schema.org Product structured data from a product record —
// shared here so ProductPage doesn't have to hand-assemble this shape.
export function productStructuredData(product, canonicalUrl) {
  if (!product) return undefined;
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    description: product.shortDescription || product.description,
    image: product.previewImages?.map((img) => img.url) || product.thumbnail,
    sku: product.productId,
    url: canonicalUrl,
    offers: {
      '@type': 'Offer',
      price: product.price,
      priceCurrency: product.currency || 'INR',
      availability: 'https://schema.org/InStock',
      url: canonicalUrl,
    },
  };
}

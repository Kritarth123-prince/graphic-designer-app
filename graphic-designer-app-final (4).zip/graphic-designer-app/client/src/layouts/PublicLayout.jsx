import { Outlet } from 'react-router-dom';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { useSiteSettings } from '../context/SiteSettingsContext';
import { useOrganizationStructuredData } from '../hooks/useDocumentMeta';

export default function PublicLayout() {
  const { settings } = useSiteSettings();
  useOrganizationStructuredData(settings);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

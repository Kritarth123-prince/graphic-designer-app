import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import AdminSidebar from '../components/admin/AdminSidebar';

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 font-sans flex">
      <AdminSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 min-w-0 flex flex-col">
        {/* Mobile-only top bar with hamburger — the sidebar itself is
            hidden off-canvas below the md breakpoint (see AdminSidebar). */}
        <div className="md:hidden h-14 flex items-center px-4 border-b border-neutral-200 bg-white sticky top-0 z-30">
          <button
            onClick={() => setSidebarOpen(true)}
            className="text-neutral-600 hover:text-neutral-900"
            aria-label="Open menu"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h18M3 12h18M3 18h18" strokeLinecap="round" />
            </svg>
          </button>
          <span className="ml-3 font-semibold text-sm">Admin</span>
        </div>

        <main className="p-4 sm:p-6 md:p-8 max-w-6xl w-full overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

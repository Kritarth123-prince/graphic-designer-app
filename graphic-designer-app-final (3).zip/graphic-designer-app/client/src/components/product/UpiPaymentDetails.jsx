import { useState } from 'react';

export default function UpiPaymentDetails({ upi }) {
  const [copied, setCopied] = useState(false);

  if (!upi?.id) return null;

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(upi.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API can fail (permissions, non-secure context) — the
      // UPI ID is still shown as plain text either way, so this isn't
      // a dead end for the customer, just a lost convenience.
    }
  }

  return (
    <div className="mt-4 border border-ink/10 p-4 text-sm">
      <p className="text-xs text-ink/40 uppercase tracking-wide">Pay via UPI</p>

      <div className="mt-2 flex items-center justify-between gap-3">
        <span className="font-mono">{upi.id}</span>
        <button
          onClick={handleCopy}
          className="text-xs border-b border-gold pb-0.5 shrink-0"
        >
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>

      {upi.qrImageUrl && (
        <img src={upi.qrImageUrl} alt="UPI QR code" className="mt-3 w-32 h-32 object-contain" />
      )}

      {upi.instructions && (
        <p className="mt-3 text-xs text-ink/60 leading-relaxed">{upi.instructions}</p>
      )}
    </div>
  );
}

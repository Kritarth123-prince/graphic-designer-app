import { useState } from 'react';

export default function UpiPaymentDetails({ upi }) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  if (!upi?.id) return null;

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(upi.id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API can fail (permissions, non-secure context) — the
      // UPI ID is still shown as plain text either way, so this isn't
      // a dead end for the customer, just a lost convenience.
    }
  }

  return (
    <div className="mt-4 border border-ink/10 p-4 text-sm">
      <p className="text-xs text-ink/40 uppercase tracking-wide">Pay via UPI</p>

      <div className="mt-2 flex items-center justify-between gap-3">
        <span className="font-mono break-all">{upi.id}</span>
        <button onClick={handleCopy} className="text-xs border-b border-gold pb-0.5 shrink-0">
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>

      {upi.qrImageUrl && (
        <>
          <button
            onClick={() => setExpanded(true)}
            className="mt-3 block cursor-zoom-in"
            aria-label="Expand QR code"
          >
            <img
              src={upi.qrImageUrl}
              alt="UPI QR code — tap to expand"
              className="w-28 h-28 sm:w-32 sm:h-32 object-contain border border-ink/10"
            />
            <span className="mt-1 block text-[11px] text-ink/40">Tap to expand</span>
          </button>

          {expanded && (
            <div
              className="fixed inset-0 z-50 bg-ink/95 flex items-center justify-center p-6"
              onClick={() => setExpanded(false)}
            >
              <div className="bg-ivory p-6 max-w-xs w-full">
                <img src={upi.qrImageUrl} alt="UPI QR code" className="w-full h-auto object-contain" />
                <p className="mt-4 text-center font-mono text-sm break-all">{upi.id}</p>
              </div>
              <button
                onClick={() => setExpanded(false)}
                className="absolute top-6 right-6 text-ivory text-sm border-b border-gold pb-0.5"
              >
                Close
              </button>
            </div>
          )}
        </>
      )}

      {upi.instructions && (
        <p className="mt-3 text-xs text-ink/60 leading-relaxed">{upi.instructions}</p>
      )}
    </div>
  );
}
